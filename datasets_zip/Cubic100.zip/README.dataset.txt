# EVA Block > Cubic100
https://universe.roboflow.com/loop-p7q2i/eva-block

Provided by a Roboflow user
License: CC BY 4.0

