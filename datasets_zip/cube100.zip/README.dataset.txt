# EVA Block Set > 2024-02-27 6:15pm
https://universe.roboflow.com/loop-p7q2i/eva-block-set

Provided by a Roboflow user
License: CC BY 4.0

